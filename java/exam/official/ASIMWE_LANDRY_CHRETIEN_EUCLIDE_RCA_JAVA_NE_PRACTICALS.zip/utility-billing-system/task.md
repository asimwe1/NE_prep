# Utility Billing System Exam Tasks

Local planning file for the WASAC/REG backend exam project. Keep this file uncommitted.

Legend:

- `[x]` implemented or scaffolded and verified
- `[ ]` not completed yet

## Scenario Summary

Build a Spring Boot backend for a national utility company context involving WASAC and REG. The system must automate customer management, meter management, meter readings, tariff/tax/penalty configuration, billing, payment processing, database routines, notifications, JWT authentication, authorization, Swagger documentation, and design diagrams.

Water is postpaid. Electricity is currently prepaid but must be supported for transition toward postpaid billing.

## Global Setup

- [x] Create exam project under `java/exam/official/utility-billing-system`
- [x] Use Spring Boot backend
- [x] Use Maven with Java 21
- [x] Add Spring Web starter
- [x] Add Spring Security starter
- [x] Add JWT dependencies
- [x] Add Spring Data JPA starter
- [x] Add PostgreSQL driver
- [x] Add H2 test database
- [x] Add Bean Validation starter
- [x] Add Mail starter
- [x] Add Thymeleaf email templates
- [x] Add Swagger/OpenAPI
- [x] Add Actuator
- [x] Add Lombok
- [x] Configure PostgreSQL dev database name `utility_billing_db`
- [x] Verify project compiles with `mvn test`
- [x] Create local `.env` for this project if running outside tests
- [x] Create PostgreSQL database `utility_billing_db`

## Task 0: Input Validation Layer

### Custom Constraint Annotations (`validation/` sub-package)

- [x] Create `@ValidName` — letters, spaces, hyphens, apostrophes only (`^[a-zA-Z\s'\-]+$`); rejects digits and special characters
- [x] Create `@ValidRwandanPhone` — matches `+2507XXXXXXX`, `2507XXXXXXX`, or `07XXXXXXX` format (`^(\+?250|0)(7[2-9]|8[0-9])[0-9]{7}$`)
- [x] Create `@ValidNationalId` — exactly 16 digits, no letters or symbols (`^[0-9]{16}$`)

### Existing DTO Patches

- [x] `RegisterRequest.fullName` → add `@ValidName`
- [x] `RegisterRequest.phoneNumber` → add `@ValidRwandanPhone`
- [x] `RegisterRequest.nationalId` → add `@NotBlank @ValidNationalId`
- [x] `RegisterRequest.password` → `@Size(min=8,max=128)` + complexity `@Pattern` (uppercase + digit required)
- [x] `ChangePasswordRequest.newPassword` → raise min to 8 + complexity `@Pattern`
- [x] `LoginRequest` → confirm `@Email @NotBlank` on email, `@NotBlank` on password

### Customer Validation

- [x] `fullName` — `@NotBlank @Size(min=2,max=100) @ValidName` (no digits)
- [x] `nationalId` — `@NotBlank @ValidNationalId` (16 digits, no letters)
- [x] `email` — `@NotBlank @Email @Size(max=255)`
- [x] `phoneNumber` — `@NotBlank @ValidRwandanPhone`
- [x] `address` — `@NotBlank @Size(min=5,max=255)`
- [x] `district` — `@NotBlank @Size(min=2,max=100) @ValidName`

### Meter Validation

- [x] `meterNumber` — `@NotBlank @Size(min=4,max=30) @Pattern(regexp="^[A-Z0-9\\-]+$")` (uppercase alphanumeric + hyphens only)
- [x] `utilityType` — `@NotNull`
- [x] `billingMode` — `@NotNull`
- [x] `companyType` — `@NotNull`
- [x] `customerNationalId` — preferred customer-facing meter assignment reference with `@ValidNationalId`
- [x] `customerId` — optional internal/backward-compatible fallback for customer profile UUID or linked user UUID
- [x] `installationDate` — `@NotNull @PastOrPresent`
- [x] `installationAddress` — `@NotBlank @Size(min=5,max=255)`

### Meter Reading Validation

- [x] `meterId` — `@NotNull`
- [x] `currentReading` — `@NotNull @DecimalMin("0.0") @Digits(integer=10,fraction=3)`
- [x] `readingDate` — `@NotNull @PastOrPresent`
- [x] `billingMonth` — `@NotNull`; reject future months in service layer
- [x] Service layer: `currentReading > previousReading` enforced (not in DTO, previous fetched from DB)

### Tariff Validation

- [x] `tariffCode` — `@NotBlank @Size(min=3,max=30) @Pattern(regexp="^[A-Z0-9_\\-]+$")`
- [x] `utilityType` / `billingMode` / `tariffType` — `@NotNull`
- [x] `version` — `@NotNull @Min(1)`
- [x] `effectiveStartCycle` — `@NotNull`
- [x] `fixedServiceCharge` — `@NotNull @DecimalMin("0.0") @Digits(integer=12,fraction=2)`
- [x] `vatRate` — `@NotNull @DecimalMin("0.0") @DecimalMax("100.0")`
- [x] `TariffTierRequest.tierMin` — `@NotNull @DecimalMin("0.0")`
- [x] `TariffTierRequest.tierMax` — `@NotNull @DecimalMin("0.01")` + service-layer check `tierMax > tierMin`
- [x] `TariffTierRequest.unitPrice` — `@NotNull @DecimalMin("0.01") @Digits(integer=10,fraction=2)`
- [x] Tax `rate` — `@NotNull @DecimalMin("0.0") @DecimalMax("100.0")`
- [x] Penalty `gracePeriodDays` — `@NotNull @Min(0) @Max(365)`

### Payment Validation

- [x] `billId` — `@NotNull`
- [x] `amount` — `@NotNull @DecimalMin("0.01") @Digits(integer=15,fraction=2)`
- [x] `paymentMethod` — `@NotBlank @Size(max=50)`
- [x] `paymentReference` — `@NotBlank @Size(min=6,max=100) @Pattern(regexp="^[A-Z0-9\\-]+$")`

### Validation Error Response

- [x] `GlobalExceptionHandler` returns field-level error map for `MethodArgumentNotValidException`
- [ ] `GlobalExceptionHandler` handles `ConstraintViolationException` from custom validators
- [x] All controllers use `@Valid` on `@RequestBody` parameters
- [x] Verify error response includes field name and human-readable message

---

## Task 1: User Management and Security (JWT)

### Required User Attributes

- [x] User entity exists
- [x] User has full names matching the exam requirement
- [x] User has email as username
- [x] User has phone number
- [x] User has National ID for customer-facing registration and customer profile linking
- [x] User has password
- [x] User has enabled/status field
- [x] Rename or map enabled/status clearly as Active/Inactive

### Required Roles

- [x] Base role enum exists
- [x] Add `ROLE_ADMIN`
- [x] Add `ROLE_OPERATOR`
- [x] Add `ROLE_FINANCE`
- [x] Add `ROLE_CUSTOMER`
- [x] Verify role names match Spring Security authorities exactly

### Functional Requirements

- [x] Signup endpoint exists
- [x] Login endpoint exists
- [x] JWT access token generation exists
- [x] JWT refresh token support exists
- [x] Password hashing exists
- [x] Most endpoints secured by Spring Security
- [x] Confirm all non-auth exam endpoints are protected
- [x] Public auth routes narrowed so profile/logout/password-change require login
- [x] Clear `401` response for missing/invalid Bearer token
- [x] Clear `403` response for authenticated users using endpoints outside their role
- [x] Add role-based authorization to operator/finance/customer endpoints when those domain endpoints are implemented
- [x] Add role-based authorization to admin user-management endpoints
- [x] Add user management endpoints for admin
- [x] Add user activation/deactivation
- [x] Add admin role update endpoint
- [ ] Add Swagger examples for auth flow
- [x] Add tests for signup/login/JWT-protected endpoints/admin access
- [x] Add tests confirming signup persists National ID

## Task 2: Customer and Meter Management

### Customer Management

Required customer details:

- [x] Customer entity exists
- [x] Full names field exists as `fullName`
- [x] National ID field exists and is unique
- [x] Email field exists
- [x] Phone number field exists
- [x] Address field exists
- [x] Active/Inactive status field exists
- [x] Customer repository exists
- [x] Add customer DTOs
- [x] Add customer service
- [x] Add customer controller
- [x] Add create customer endpoint
- [x] Add update customer endpoint
- [x] Add list customers endpoint
- [x] Add get customer by ID endpoint
- [x] Add get customer by National ID endpoint
- [x] Add activate/deactivate customer endpoint
- [x] Prevent duplicate customer registration in service layer
- [x] Return clear validation error for duplicate national ID
- [x] Ensure inactive customers cannot receive bills
- [x] Add tests for duplicate customer prevention
- [x] Add tests for inactive customer billing rule

### Meter Management

Required meter details:

- [x] UtilityMeter entity exists
- [x] Meter number field exists and is unique
- [x] Meter type exists as `UtilityType` with WATER/ELECTRICITY
- [x] Installation date field exists
- [x] Active/Inactive status field exists
- [x] Customer-to-meter relationship exists
- [x] Meter repository exists
- [x] Add meter DTOs
- [x] Add meter service
- [x] Add meter controller
- [x] Add assign meter endpoint
- [x] Assign meter by customer National ID as the preferred Swagger/Postman workflow
- [x] Add update meter endpoint
- [x] Add list meters endpoint
- [x] Add list customer meters endpoint
- [x] Add list customer meters by National ID endpoint
- [x] Prevent duplicate meter number
- [x] Ensure each meter belongs to one customer
- [x] Add tests for duplicate meter prevention

## Task 3: Meter Reading Management

Required meter reading fields:

- [x] MeterReading entity exists
- [x] Meter relationship exists
- [x] Previous reading field exists
- [x] Current reading field exists
- [x] Reading date field exists separately from billing month
- [x] Billing month field exists
- [x] Consumption field exists
- [x] Meter reading repository exists

Business rules:

- [x] Current reading must be greater than previous reading
- [x] Only one reading per meter per Month/Year is represented by unique constraint
- [x] Enforce one reading per meter per Month/Year in service layer
- [x] Meter must be active before reading can be captured
- [x] Add meter reading DTOs
- [x] Add meter reading service
- [x] Add meter reading controller
- [x] Add capture reading endpoint for ROLE_OPERATOR
- [x] Add list readings endpoint
- [x] Add tests for current reading greater than previous reading
- [x] Add tests for one reading per month/year
- [x] Add tests preventing inactive meter readings

## Task 4: Tariff, Tax, and Penalty Configuration

Required admin configuration:

- [x] Add Tariff entity
- [x] Add tariff type for FLAT and TIER_BASED
- [x] Add tariff version field
- [x] Add tariff effective start cycle/date
- [x] Add tariff effective end cycle/date
- [x] Add fixed service charge field
- [x] Add VAT/tax rate field
- [x] Add late payment penalty configuration
- [x] Add tariff repository
- [x] Add tariff DTOs
- [x] Add tariff service
- [x] Add tariff controller
- [x] Restrict tariff configuration to ROLE_ADMIN

Rules:

- [x] Tariffs must be versioned
- [x] New tariffs apply only to future billing cycles (effectiveStartCycle must be current month or later)
- [x] Prevent editing applied historical tariffs directly (deactivate old, create new version)
- [x] Resolve active tariff by utility type and billing cycle
- [x] Add tests for tariff versioning
- [x] Add tests that new tariffs do not affect old bills

## Task 5: Bill Generation and Payment Processing

### Bill Generation

- [x] Bill entity exists
- [x] Bill repository exists
- [x] Add `BillGenerateRequest` DTO with `meterId` + `billingMonth` validation
- [x] Add `BillResponse` DTO
- [x] Add `BillService` with full calculation pipeline
- [x] Add `BillController` at `/api/v1/bills`
- [x] `POST /generate` — `ROLE_ADMIN` or `ROLE_FINANCE`
- [x] `GET /` — `ROLE_ADMIN` or `ROLE_FINANCE`
- [x] `GET /{id}` — `ROLE_ADMIN`, `ROLE_FINANCE`, or `ROLE_CUSTOMER`
- [x] `GET /customer/{customerId}` — `ROLE_ADMIN`, `ROLE_FINANCE`, or `ROLE_CUSTOMER`
- [x] `GET /customer/national-id/{nationalId}` — `ROLE_ADMIN`, `ROLE_FINANCE`, or `ROLE_CUSTOMER`

Bill calculation rules:

- [x] Guard: customer must be ACTIVE before bill is generated
- [x] Load meter reading for the billing month
- [x] Resolve active tariff by utility type + billing mode + billing month
- [x] FLAT: `consumption × tier[0].unitPrice`
- [x] TIER_BASED: iterate tiers sorted by `tierMin`, apply sliced consumption amounts
- [x] Add `fixedServiceCharge` to base amount
- [x] Add VAT: `(base + fixedCharge) × vatRate / 100`
- [x] Add penalty if `billingMonth end + gracePeriodDays < today`
- [x] Set `paidAmount = 0`, `balance = totalAmount`, `status = PENDING`
- [x] Generate unique bill number (`BILL-YYYYMM-XXXXXX` format)
- [x] Set `dueDate = today + 30 days`
- [x] Add tests for bill generation calculation

### Payment Processing

Required payment fields:

- [x] Payment entity exists
- [x] Bill reference relationship exists
- [x] Amount paid field exists
- [x] Payment method field exists
- [x] Payment date exists as `paidAt`
- [x] Payment repository exists
- [x] Add `PaymentRequest` DTO with full validation
- [x] Add `PaymentResponse` DTO
- [x] Add `PaymentService` with all business rules
- [x] Add `PaymentController` at `/api/v1/payments`
- [x] `POST /` — `ROLE_FINANCE`
- [x] `GET /` — `ROLE_FINANCE`
- [x] `GET /bill/{billId}` — `ROLE_ADMIN` or `ROLE_FINANCE`

Rules:

- [x] Support partial payments (status → `PARTIALLY_PAID`)
- [x] Support full payments (status → `PAID`)
- [x] Automatically update `paidAmount` and `balance` on bill
- [x] Mark bill as PAID when balance reaches zero
- [x] Prevent overpayment — throws `OverpaymentException` (400) if `amount > balance`
- [x] Reject duplicate payment references
- [x] Reject payment against an already-PAID bill
- [x] Add tests for partial payment
- [x] Add tests for full payment
- [x] Add tests for bill status transition to PAID

## Task 6: Database Routines and Messaging

Required database-level routines:

- [x] Add PostgreSQL trigger for bill generation notification (`trg_bill_notification`)
- [x] Add PostgreSQL trigger for full payment status update (`trg_payment_bill_status`)
- [x] Add db routine SQL file at `src/main/resources/db/routines.sql`
- [x] Ensure routines are PostgreSQL compatible (PLPGSQL)

Required behavior:

- [x] On bill generation, insert a notification record (handled in `NotificationService`)
- [x] On full payment, update bill status to PAID (handled in `PaymentService`)
- [x] On full payment, notify customer (handled in `NotificationService.notifyPaymentReceived`)

Required message format:

```text
Dear <CustomerName>,
Your <Month/Year> utility bill of <Amount> FRW has been successfully processed.
```

Messaging implementation:

- [x] Email service exists
- [x] Notification entity exists
- [x] Notification repository exists
- [x] Add `NotificationService` — persists `CustomerNotification`, sends email, marks SENT/FAILED
- [x] Add `NotificationController` at `/api/v1/notifications`
  - `GET /` — `ROLE_ADMIN`
  - `GET /customer/{customerId}` — `ROLE_ADMIN` or `ROLE_CUSTOMER`
  - `GET /customer/national-id/{nationalId}` — `ROLE_ADMIN` or `ROLE_CUSTOMER`
- [x] Add `bill-generated.html` Thymeleaf email template
- [x] Add `payment-received.html` Thymeleaf email template
- [x] Persist notification records from backend service
- [x] Send email notification through SMTP (async via `EmailService.sendCustomEmail`)
- [x] Add PostgreSQL triggers to satisfy DB-routine exam requirement
- [x] Add tests for notification creation

## Design Instructions

### ERD

- [x] Design ERD before coding additional business endpoints
- [x] Create dbdiagram.io compatible ERD script
- [x] Include users and roles
- [x] Include customers
- [x] Include meters
- [x] Include meter readings
- [x] Include tariffs/taxes/penalties
- [x] Include bills
- [x] Include payments
- [x] Include notifications
- [x] Include key constraints and relationships
- [x] Save ERD script under a docs/design path

### Spring Boot Flow Diagram

- [x] Design Spring Boot flow diagram script
- [x] Use Mermaid or dbdiagram-compatible style as requested
- [x] Show auth flow
- [x] Show customer/meter/reading flow
- [x] Show bill generation flow
- [x] Show payment flow
- [x] Show notification flow
- [x] Save flow diagram under a docs/design path

## API Documentation

- [x] Swagger UI dependency exists
- [x] OpenAPI configuration exists
- [x] Document customer APIs
- [x] Document meter APIs
- [x] Document reading APIs
- [x] Document tariff APIs (`@Tag`, `@Operation`, `@SecurityRequirement` on `TariffController`)
- [x] Document bill APIs (`@Tag`, `@Operation`, `@SecurityRequirement` on `BillController`)
- [x] Document payment APIs (`@Tag`, `@Operation`, `@SecurityRequirement` on `PaymentController`)
- [x] Document notification APIs (`@Tag`, `@Operation`, `@SecurityRequirement` on `NotificationController`)
- [x] Add role/security descriptions to Swagger
- [x] Document National ID as the preferred customer identifier in Swagger descriptions
- [x] Verify Swagger opens at `/swagger-ui.html`

## Codebase Documentation

- [x] comments only where needed (complex logic or reason of approach)
- [x] clean Javadoc implementation where useful for completed application rules

## Data Entry and Testing

Allowed ways to add records:

- [x] Swagger
- [x] Postman
- [x] Application main class seed data
- [x] DBMS-level inserts

Testing checklist:

- [x] Auth integration tests pass (9/9)
- [x] Add customer tests
- [x] Add meter tests
- [x] Add reading tests
- [x] Add tariff tests
- [x] Add bill tests
- [x] Add payment tests
- [x] Add notification tests
- [x] Run full `mvn test` after each major feature — all 59 tests passing
- [x] Run full `mvn test` after National ID refinement — all 69 tests passing

## Current Implementation Gaps To Fix Next

- [x] Remove or replace sample `Item` CRUD with exam-specific resources
- [x] Update `User` fields to include phone number and explicit Active/Inactive status
- [x] Update roles to exact exam roles
- [x] Add installation date to `UtilityMeter`
- [x] Add reading date to `MeterReading`
- [x] Add tariff/tax/penalty entities
- [x] Add services/controllers/DTOs for customer, meter, and reading domain
- [x] Add services/controllers/DTOs for tariff, bill, payment, and notification domain
- [x] Add database routine SQL (`src/main/resources/db/routines.sql`)
- [x] Add ERD and Spring Boot flow diagrams
