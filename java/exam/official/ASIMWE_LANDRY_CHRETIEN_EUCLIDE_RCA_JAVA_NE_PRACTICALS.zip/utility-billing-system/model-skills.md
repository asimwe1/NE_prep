# Model Skills For Utility Billing Exam

Local AI guidance file for this specific WASAC/REG Spring Boot backend. Keep this file uncommitted.

## Primary Objective

Assist with implementing a secure Spring Boot backend for utility billing with strict business rules, PostgreSQL persistence, JWT authentication, role-based authorization, billing calculations, database routines, messaging, and Swagger documentation.

## Domain Understanding Required

- Understand WASAC as the water utility company.
- Understand REG as the electricity utility company.
- Water billing is postpaid.
- Electricity is currently prepaid but must support transition to postpaid.
- Customers can own multiple meters.
- Each meter belongs to exactly one customer.
- Meters can be WATER or ELECTRICITY.
- Meters can be Active or Inactive.
- Customers can be Active or Inactive.
- Inactive customers cannot receive bills.
- Inactive meters cannot receive readings.
- Monthly readings are used to calculate consumption.
- A bill belongs to a customer and a meter.
- Payments can be partial or full.
- Notifications must be generated on bill generation and full payment.

## Engineering Skills Required

- Spring Boot REST API design
- Spring Security configuration
- JWT access token and refresh token implementation
- Role-based endpoint authorization
- Spring Data JPA entity modeling
- PostgreSQL relational database design
- Bean Validation with clear error messages
- Transactional service-layer business rules
- Swagger/OpenAPI documentation
- Java Mail / SMTP messaging
- Thymeleaf email template usage
- Maven build and test execution
- Integration testing with Spring Boot Test and MockMvc
- SQL trigger/stored procedure/cursor design for PostgreSQL
- dbdiagram.io ERD scripting
- Mermaid flow diagram scripting

## Mandatory Role Model

Use these exact roles unless the user explicitly changes them:

- `ROLE_ADMIN`: configure tariffs, approve bills, manage users
- `ROLE_OPERATOR`: capture meter readings
- `ROLE_FINANCE`: approve bills and payments
- `ROLE_CUSTOMER`: view bills and payment history

When adding endpoints:

- Authentication endpoints must remain public.
- Customer self-service endpoints should require `ROLE_CUSTOMER`.
- Reading capture endpoints should require `ROLE_OPERATOR`.
- Tariff configuration endpoints should require `ROLE_ADMIN`.
- Bill approval endpoints should require `ROLE_ADMIN` or `ROLE_FINANCE` depending on the final rule.
- Payment approval/recording endpoints should require `ROLE_FINANCE`.
- User management endpoints should require `ROLE_ADMIN`.

## Required Business Rules

Always enforce these in the service layer, not only in the database:

- Duplicate users by email are not allowed.
- Duplicate customers by National ID are not allowed.
- Duplicate meter numbers are not allowed.
- Current meter reading must be greater than previous reading.
- Only one reading per meter per Month/Year is allowed.
- Meter must be active before capturing readings.
- Customer must be active before generating bills.
- Tariffs must be versioned.
- A new tariff must apply only to future billing cycles.
- Payments must update bill paid amount and outstanding balance.
- Partial payment leaves bill in `PARTIALLY_PAID`.
- Full payment sets bill to `PAID`.
- Full payment creates a customer notification.
- Bill generation creates a customer notification.

## Entity Modeling Guidance

Preferred core entities:

- `User`
- `Customer`
- `UtilityMeter`
- `MeterReading`
- `Tariff`
- `TariffTier`
- `TaxConfiguration`
- `PenaltyConfiguration`
- `Bill`
- `Payment`
- `CustomerNotification`

Preferred enums:

- `Role`
- `UserStatus`
- `CustomerStatus`
- `MeterStatus`
- `CompanyType`
- `UtilityType`
- `BillingMode`
- `TariffType`
- `BillStatus`
- `PaymentStatus`
- `NotificationStatus`
- `NotificationType`

Use `UUID` primary keys unless the user requests numeric IDs.

## API Design Guidance

Use versioned REST endpoints:

- `/api/v1/auth`
- `/api/v1/users`
- `/api/v1/customers`
- `/api/v1/meters`
- `/api/v1/readings`
- `/api/v1/tariffs`
- `/api/v1/bills`
- `/api/v1/payments`
- `/api/v1/notifications`

For list endpoints:

- Keep pagination simple with `page` and `size`.
- Avoid exposing sort parameters unless explicitly required.
- Return DTOs, not entities.

## Billing Calculation Guidance

When implementing billing:

- Calculate consumption as `currentReading - previousReading`.
- Resolve tariff by utility type, billing mode, and billing month.
- Add fixed service charge.
- Add VAT/tax.
- Add penalty only when late-payment rules apply.
- Store bill amount, paid amount, and balance.
- Do not recalculate old bills when tariff versions change.

If tier-based tariffs are required:

- Apply each tier only to the consumption range it covers.
- Store tier minimum and maximum consumption.
- Store unit price per tier.

## Database Routine Guidance

The exam requires at least one database-level routine: trigger, stored procedure, or cursor.

Recommended PostgreSQL approach:

- Trigger on `bills` insert to create a `customer_notifications` row.
- Trigger on `payments` insert or bill balance update to mark bill `PAID` and create a notification when balance reaches zero.

Keep backend service logic too. Database routines satisfy exam requirement, but service-layer logic keeps application behavior explicit and testable.

## Required Notification Message

Use this exact format for the required routine/message unless the user changes it:

```text
Dear <CustomerName>,
Your <Month/Year> utility bill of <Amount> FRW has been successfully processed.
```

## Diagram Skills

Before adding more business code, generate:

- dbdiagram.io ERD script
- Spring Boot flow diagram script

ERD must include:

- Tables
- Primary keys
- Foreign keys
- Unique constraints
- Status fields
- Tariff versioning
- Bill/payment/notification relationships

Flow diagram must include:

- Auth/login/token flow
- Customer/meter setup flow
- Meter reading flow
- Bill generation flow
- Payment processing flow
- Notification flow
- Role authorization gates

## Verification Rules

After each implementation step:

- Update `task.md` checkboxes honestly.
- Run `mvn test` when code changes are made.
- Do not mark a task as done unless implementation exists and compiles.
- Mention any untested behavior explicitly.
- Keep secrets in `.env`, never in committed files.
- Keep `task.md` and `model-skills.md` uncommitted unless the user explicitly asks otherwise.

## Current Project Notes

- Project path: `java/exam/official/utility-billing-system`
- Current package remains `com.template` for stability.
- Main class is `UtilityBillingApplication`.
- Maven target uses Java 21.
- PostgreSQL database name is `utility_billing_db`.
- Existing auth starter is available but must be adapted to exact exam roles and user fields.
- Existing sample `Item` CRUD should be removed or ignored after exam-specific endpoints are implemented.
